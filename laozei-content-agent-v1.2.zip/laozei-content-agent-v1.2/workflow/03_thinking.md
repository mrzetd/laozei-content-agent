# 03_thinking Workflow
