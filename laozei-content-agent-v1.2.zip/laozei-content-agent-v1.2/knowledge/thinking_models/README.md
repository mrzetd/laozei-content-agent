# thinking_models
